<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test case alami</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>2c0e9813-9af6-489d-beca-04222f4a6b4b</testSuiteGuid>
   <testCaseLink>
      <guid>bb5d18b7-1a4a-472d-951c-83458111caf3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test case alami/Test case Daftar Disini</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>d13dfa88-1778-4b6a-bd76-e62e363e4f38</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test case alami/Test Case Daftar</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>1c108169-a4eb-4bf6-bf22-0b04eeebef86</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test case alami/Test case login</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>f758dab2-b457-409c-bf0f-e5c4749a4e89</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test case alami/Test case pendanaan</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ceb36508-dc74-4566-adfc-a671ca9588ff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test case alami/Test case Portopolio</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    